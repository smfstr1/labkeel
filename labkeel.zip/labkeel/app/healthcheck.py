"""Docker health check: is the dashboard answering? Works with HTTPS on or off."""
import os
import ssl
import sys
import urllib.request

host = os.environ.get("DASH_HOST", "0.0.0.0")
host = "127.0.0.1" if host in ("0.0.0.0", "::", "") else host
port = os.environ.get("DASH_PORT", "8787")
scheme = "http" if os.environ.get("DASH_TLS", "auto").lower() == "off" else "https"
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE  # only checking that it answers; the certificate is for the real name
try:
    with urllib.request.urlopen(f"{scheme}://{host}:{port}/api/health", timeout=5, context=ctx) as r:
        sys.exit(0 if r.status == 200 else 1)
except Exception:
    sys.exit(1)
